# @10up/wp-vite-plugins

Vite plugins for building modern WordPress projects the 10up way.

A focused set of Vite plugins that handle what WordPress projects actually need: `block.json` discovery, `@wordpress/*` externals with `.asset.php` emission, per-block style entries, and static asset copying.

## Install

```sh
npm install --save-dev @10up/wp-vite-plugins
```

Requires Node ≥ 20.11 and Vite ^8 (Rolldown-powered).

### Vite+ / Rolldown compatibility

The plugins use only Rolldown-implemented plugin APIs, so they work unchanged with [Vite+](https://viteplus.dev) — `vp dev`, `vp build`, and `vp build --mode modules` read the same `vite.config.ts` and produce identical output to plain `vite` commands. The test suite runs under `vp test` (Vitest) as well.

## Quick start

The `wp()` composer covers the common case. Point it at your block directory and you're done:

```ts
import { defineConfig } from 'vite';
import { wp } from '@10up/wp-vite-plugins';

export default defineConfig({
  plugins: [
    wp({
      blocksDir: './includes/blocks',
      blocksStylesDir: './assets/css/blocks',
      copyAssetsDir: './assets',
    }),
  ],
});
```

That single call wires up:

- **`wpBlocks`** — discovers every `block.json`, turns `file:` references into Rollup entries, copies `block.json` + sibling PHP into `dist/`, and emits `blocks-manifest.php` (WP 6.7+).
- **`wpBlockStyles`** — emits each stylesheet under `blocksStylesDir` as its own CSS entry for selective PHP enqueueing.
- **`wpCopyAssets`** — copies images / fonts / SVG from `copyAssetsDir` to `dist/`.
- **`wpExternals`** — rewrites `@wordpress/*` imports against `window.wp.*` (or preserves them as ESM in module mode) and emits `<entry>.asset.php` dependency sidecars.
- **`wpScriptIife`** _(auto)_ — wraps script-mode entries in an IIFE so they enqueue cleanly as classic `<script>` tags.
- **`wpCleanCssChunks`** _(auto)_ — deletes the empty JS shims Vite leaves next to CSS-only entries.

## Wrapper options

```ts
wp({
  // Build mode for all sub-plugins. Default: 'script'.
  buildType: 'script', // or 'module'

  // Top-level shortcuts — pass a directory to enable the plugin.
  blocksDir:       './includes/blocks',
  blocksStylesDir: './assets/css/blocks',
  copyAssetsDir:   './assets',

  // Per-plugin escape hatches. Nested wins on conflict. Pass `false` to disable entirely.
  blocks:      { skip: ['legacy-block'] },
  blockStyles: { /* extra WpBlockStylesOptions */ },
  copyAssets:  { pattern: '**/*.{png,svg}' },
  externals: {
    scriptModuleNamespaces: ['ignite-*'],
    additionalExternals:    { myLib: { global: 'MyLib', handle: 'my-lib' } },
  },

  // Helper opt-outs.
  iife:           false, // disable wpScriptIife (script mode only)
  cleanCssChunks: false, // disable wpCleanCssChunks (auto-on when blockStyles is active)
});
```

`externals` is always included unless you pass `externals: false`. The other three are included only when their directory option is provided (top-level or nested). See [docs/wp.md](./docs/wp.md) for the full inclusion and option-merging rules.

## Dual-pass builds (script + module)

For projects that ship both classic scripts and Script Modules, dispatch on Vite's `mode`:

```ts
export default defineConfig(({ mode }) => ({
  plugins: [
    wp({
      buildType: mode === 'modules' ? 'module' : 'script',
      blocksDir: './includes/blocks',
    }),
  ],
}));
```

Run the two passes separately: `vite build` (default script mode) and `vite build --mode modules`. The module pass is safe to run unconditionally — when no block declares a `scriptModule` / `viewScriptModule` (and no other module entries are configured), `wpBlocks` turns it into a no-op build instead of letting Rollup error on empty input.

## Using plugins individually

The wrapper is just sugar. Every plugin is exported on its own for finer control:

```ts
import { defineConfig } from 'vite';
import {
  wpBlocks,
  wpBlockStyles,
  wpCopyAssets,
  wpExternals,
  wpScriptIife,
  wpCleanCssChunks,
} from '@10up/wp-vite-plugins';

export default defineConfig({
  plugins: [
    wpBlocks({ blocksDir: './includes/blocks', buildType: 'script' }),
    wpBlockStyles({ blocksStylesDir: './assets/css/blocks' }),
    wpCopyAssets({ copyAssetsDir: './assets' }),
    wpExternals({ buildType: 'script' }),
    wpScriptIife(),
    wpCleanCssChunks(),
  ],
});
```

## Examples

Two runnable consumer projects live under [`examples/`](./examples/README.md), each with a WordPress Playground blueprint for end-to-end verification:

- [`examples/minimal-block-plugin`](./examples/minimal-block-plugin) — one plugin, one block, single-pass build.
- [`examples/scaffold-monorepo`](./examples/scaffold-monorepo) — a full [10up/wp-scaffold](https://github.com/10up/wp-scaffold)-style monorepo (classic theme, block theme, mu-plugin) building through npm workspaces, including a dual-pass Script Module build.

## Plugins

The sections below are the quick reference. Each plugin also has an in-depth page under [`docs/`](./docs/README.md) covering internals, output formats, and caveats.

### `wpBlocks(options)`

→ [Full documentation](./docs/wp-blocks.md)

Scans `blocksDir` for `block.json` files. For each one:

- Discovers `file:`-prefixed assets and registers them as Rollup entries.
- Copies `block.json` (with `file:` references rewritten to `.js` / `.css`) and any sibling PHP files into `dist/blocks/<block-name>/`.
- Stamps a SHA-256 `version` hash on the block when no explicit version is set (hashes the source style content, not the built output).
- Emits `blocks-manifest.php` for `wp_register_block_types_from_metadata_collection` (WP 6.7+).

**Options**

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `blocksDir` | `string` | (required) | Root directory containing `block.json` files. |
| `buildType` | `'script' \| 'module'` | `'script'` | Which `block.json` fields to discover as entries. |
| `emitManifest` | `boolean` | `true` | Emit `blocks-manifest.php`. |
| `skip` | `string[]` | `[]` | Block directory names (relative to `blocksDir`) to skip entirely. |

### `wpExternals(options)`

→ [Full documentation](./docs/wp-externals.md)

Decides which imports to externalize and emits `<entry>.asset.php` sidecars.

For `@wordpress/*` packages, the decision reads each package's *own* `package.json`:

- `wpScript: true` → classic script externalization (rewrites `import { foo } from '@wordpress/x'` to `const { foo } = window.wp.x` and lists `wp-x` as a dependency handle).
- `wpScriptModuleExports` → Script Module externalization (preserves the ESM import for WP's import map; lists the specifier in `.asset.php`).
- Neither → bundle into the consumer's output (no special handling).

For non-`@wordpress/*` packages, a hardcoded vendor map covers `react`, `react-dom`, `jquery`, `lodash`, `moment`. Pass `additionalExternals` to extend or replace that map.

**Options**

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `projectRoot` | `string` | `process.cwd()` | Resolution root for `@wordpress/*` package metadata. |
| `buildType` | `'script' \| 'module'` | `'script'` | Controls import rewriting strategy. |
| `externalNamespaces` | `Record<string, ExternalNamespace>` | `{}` | Add classic-script externals for namespaces like `@woo/*`. |
| `additionalExternals` | `Record<string, { global, handle }>` | (vendor map) | Override the non-scoped vendor externals. |
| `moduleEntryMatchers` | `string[]` | `[]` | File path substrings that should be treated as module-mode regardless of `buildType`. |
| `scriptModuleNamespaces` | `string[]` | `[]` | Plugin-local Script Module namespaces (exact or `prefix-*` glob). |

### `wpBlockStyles(options)`

→ [Full documentation](./docs/wp-block-styles.md)

Every stylesheet under `blocksStylesDir` becomes a dedicated CSS entry under `dist/autoenqueue/<block-name>/<file>.css`. Lets PHP selectively enqueue per-block stylesheets without bundling.

**Options**

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `blocksStylesDir` | `string` | (required) | Directory of per-block stylesheets. |

### `wpCopyAssets(options)`

→ [Full documentation](./docs/wp-copy-assets.md)

Copies static assets (images, fonts, SVG) from `copyAssetsDir` to `dist/`, preserving the relative path. So `assets/images/logo.svg` → `dist/images/logo.svg`.

**Options**

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `copyAssetsDir` | `string` | (required) | Source directory. |
| `pattern` | `string` | `**/*.{jpg,jpeg,png,gif,webp,avif,ico,svg,eot,ttf,woff,woff2,otf}` | Glob, relative to `copyAssetsDir`. |
| `buildType` | `'script' \| 'module'` | `'script'` | Only runs in script mode (to avoid double-emission on dual-pass builds). |

### `wpScriptIife()`

→ [Full documentation](./docs/wp-script-iife.md)

Wraps each script-mode entry chunk in an IIFE in `writeBundle`. Avoids global-scope leaks when WP enqueues bundles as classic `<script>` tags. No options.

### `wpCleanCssChunks()`

→ [Full documentation](./docs/wp-clean-css-chunks.md)

Deletes the empty `.js` shim Vite emits next to a CSS-only entry. No options.

## License

GPL-2.0-or-later. See [LICENSE](./LICENSE).
